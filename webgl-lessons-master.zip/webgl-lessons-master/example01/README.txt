A zooming Mandelbrot set in a WebGL canvas, all calculations done on the
graphics hardware using a fragment shader.

See <http://learningwebgl.com/blog/?p=205> for more details.